<?php $__env->startSection('content'); ?>

<!-- breadcrumb begin  -->
    <div class="breadcrumb-pok">
        <img class="br-shape-left" src="assets/img/breadcrumb/left-bg.png" alt="">
        <img class="br-shape-right" src="assets/img/breadcrumb/right-bg.png" alt="">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-8">
                    <div class="breadcrumb-content">
                        <span class="subtitle">সাইন আপ</span>
                        <h2 class="title">একটি অ্যাকাউন্ট তৈরি করতে সাইন-আপ করুন</h2>
                        <div class="page-links">
                            <ul>
                                <li>
                                    <a href="/">Home</a>
                                </li>
                                <li>
                                    <span class="current-page">সাইন আপ</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end  -->

    <!-- sign-up begin -->
    <div class="sign-up">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10 col-lg-10">
                    <div class="poklotto-form" id="poklotto_register_form">
                        <h3 class="steps-heading-title title">Getting started</h3>
                        <div class="part-form">
                            <form method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-all-step">
                                    <div class="first-step-form per-step animate__animated blanked">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <label class="form-label">Phone number</label>
                                                <input type="text" name="phone_number" value="<?php echo e(old('phone_number')); ?>" placeholder="Ex: 123456789">

                                                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                           <div class="col-xl-12">
                                                <label class="form-label">Password</label>
                                                <input type="password" name="password" placeholder="Enter password">

                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-xl-12">
                                                <label class="form-label">Confirm Password</label>
                                                <input type="password" name="password_confirmation" placeholder="Confirm password">

                                                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-controller">
                                    <button class="btn-pok" id="nxt-stp-btn">
                                        Submit <i class="fa-solid fa-angles-right"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- sign-up end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kabbya/Desktop/ecommerce/lattery/resources/views/auth/register.blade.php ENDPATH**/ ?>