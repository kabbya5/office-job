@extends('layouts.app')

@section('content')

<!-- breadcrumb begin  -->
    <div class="breadcrumb-pok">
        <img class="br-shape-left" src="assets/img/breadcrumb/left-bg.png" alt="">
        <img class="br-shape-right" src="assets/img/breadcrumb/right-bg.png" alt="">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-8">
                    <div class="breadcrumb-content">
                        <span class="subtitle">সাইন আপ</span>
                        <h2 class="title">একটি অ্যাকাউন্ট তৈরি করতে সাইন-আপ করুন</h2>
                        <div class="page-links">
                            <ul>
                                <li>
                                    <a href="/">Home</a>
                                </li>
                                <li>
                                    <span class="current-page">সাইন আপ</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end  -->

    <!-- sign-up begin -->
    <div class="sign-up">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10 col-lg-10">
                    <div class="poklotto-form" id="poklotto_register_form">
                        <h3 class="steps-heading-title title">Getting started</h3>
                        <div class="part-form">
                            <form method="POST" action="{{ route('register') }}">
                                @csrf
                                <div class="form-all-step">
                                    <div class="first-step-form per-step animate__animated blanked">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <label class="form-label">Phone number</label>
                                                <input type="text" name="phone_number" value="{{ old('phone_number') }}" placeholder="Ex: 123456789">

                                                @error('phone_number')
                                                    <div class="text-danger mt-1">{{ $message }}</div>
                                                @enderror
                                            </div>
                                           <div class="col-xl-12">
                                                <label class="form-label">Password</label>
                                                <input type="password" name="password" placeholder="Enter password">

                                                @error('password')
                                                    <div class="text-danger mt-1">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="col-xl-12">
                                                <label class="form-label">Confirm Password</label>
                                                <input type="password" name="password_confirmation" placeholder="Confirm password">

                                                @error('password_confirmation')
                                                    <div class="text-danger mt-1">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-controller">
                                    <button class="btn-pok" id="nxt-stp-btn">
                                        Submit <i class="fa-solid fa-angles-right"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- sign-up end -->

@endsection
