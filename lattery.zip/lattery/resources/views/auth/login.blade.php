@extends('layouts.app')

@section('content')
    <div class="breadcrumb-pok">
            <img class="br-shape-left" src="assets/img/breadcrumb/left-bg.png" alt="">
            <img class="br-shape-right" src="assets/img/breadcrumb/right-bg.png" alt="">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-7 col-lg-8">
                        <div class="breadcrumb-content">
                            <span class="subtitle">সাইন ইন</span>
                            <h2 class="title">প্রবেশ করতে সাইন ইন করুন, যদি আপনার একটি অ্যাকাউন্ট থাকে।</h2>
                            <div class="page-links">
                                <ul>
                                    <li>
                                        <a href="#">Home</a>
                                    </li>
                                    <li>
                                        <span class="current-page">সাইন ইন</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb end  -->

        <!-- sign-in begin -->
        <div class="sign-in">
            <div class="container">
                <div class="row justify-content-lg-between justify-content-center">
                    <div class="col-xl-5 col-lg-6">
                        <div class="poklotto-form">
                            <h3 class="title">ফর্মটিও পূরণ করুন।</h3>
                            <div class="part-form">
                                <form>
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <label for="phone" class="form-label">Phone Number</label>
                                            <input
                                                type="tel"
                                                id="phone"
                                                name="phone"
                                                value="{{ old('phone') }}"
                                                class="form-control @error('phone') is-invalid @enderror"
                                                placeholder="Ex: 01XXXXXXXXX"
                                            >

                                            @error('phone')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="col-xl-12">
                                            <label for="password" class="form-label">Password</label>
                                            <input
                                                type="password"
                                                id="password"
                                                name="password"
                                                class="form-control @error('password') is-invalid @enderror"
                                                placeholder="Password here..."
                                            >

                                            @error('password')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="part-submit">
                                        <button class="btn-pok">
                                            সাইন ইন <i class="fa-solid fa-angle-right"></i>
                                        </button>
                                        <p>No account yet in Poklotto?
                                            <a class='reg-link' href="{{route('register')}}">Register</a> here to signup.</p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-5 col-md-8 col-sm-10 d-xl-flex d-lg-flex d-block align-items-center">
                        <div class="part-right">
                            <div class="part-img">
                                <img src="assets/img/sign-in/sign-in-img.png" alt="">
                            </div>
                            <div class="part-text">
                                <div class="section-title">
                                    <h3 class="sub-title">Welcome to xKash Pay</h3>
                                    <h2 class="title">সাইন ইন করুন এবং মাত্র এক ক্লিকে আপনার ভাগ্যবান নম্বরটি বেছে নিন।</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- sign-in end -->
@endsection
