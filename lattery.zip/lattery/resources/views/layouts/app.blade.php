
<!DOCTYPE html>
<html lang="zxx">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>xKash Pay- স্বাগতম আমাদের লটারি প্ল্যাটফর্মে!</title>
        <!-- favicon -->
        <link rel="shortcut icon" href="{{ asset('favicon.ico') }}" type="image/x-icon">
        <!-- bootstrap -->
        <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
        <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
        <!-- animate css -->
        <link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/animate.min.css') }}">
        <!-- load all Font Awesome styles -->
        <link rel="stylesheet" href="{{ asset('assets/css/all.min.css') }}">
        <!-- owl carousel css -->
        <link rel="stylesheet" href="{{ asset('assets/css/owl.carousel.min.css') }}">
        <!-- main css -->
        <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    </head>
    <body>

        <!-- preloader begin -->
        <div class="preloader">
            <div class="loader"><div></div><div></div><div></div><div></div></div>
        </div>
        <!-- preloader end -->
        
        <!-- header begin -->
        <div class="header">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 d-xl-flex d-lg-flex d-block align-items-center">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-6 d-xl-block d-lg-block d-flex align-items-center">
                                <div class="logo">
                                    <a href="index.html">
                                        <img src="assets/img/xlogo.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-6 d-xl-none d-lg-none d-flex justify-content-end">
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <i class="fa-solid fa-bars"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="main-menu">
                            <nav class="navbar navbar-expand-lg">
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav m-auto">
                                        <li class="nav-item">
                                            <a class='nav-link active' href="index.html">হোম</a>
                                        </li>
                                        
                                        <li class="nav-item">
                                            <a class='nav-link' href="lotteries.html">সকল লটারি</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class='nav-link' href="winners.html">বিজয়ীরা</a>
                                        </li>
                                        @auth
                                            <li class="nav-item">
                                                <a class="nav-link" href="{{ route('dashboard') }}">Dashboard</a>
                                            </li>
                                        @endauth

                                        @guest
                                            <li class="nav-item">
                                                <a class="nav-link" href="{{ route('login') }}">সাইন ইন</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="{{ route('register') }}">সাইন আপ</a>
                                            </li>
                                        @endguest
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 d-xl-flex d-lg-flex d-none align-items-center justify-content-end">
                        <a class='btn-pok mid' href="lotteries.html">
                            লটারি কিনুন <i class="fa-solid fa-angle-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- header end -->

        <div class="content">
            @yield('content')
        </div>

        <!-- footer begin -->
        <div class="footer">
            <div class="footer-top">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-4 col-lg-5 col-md-7 col-sm-9">
                            <div class="part-about">
                                <div class="footer-logo">
                                    <a href='/poklotto/'>
                                        <img src="{{ asset('assets/img/xlogo.png') }}" alt="" class="logo">
                                    </a>
                                </div>
                                <p>লটারি খেলোয়াড়রা বাংলাদেশের যেকোনো জায়গা থেকে ফোন, ট্যাবলেট বা কম্পিউটারে অনলাইনে লটারি খেলতে পারেন।</p>
                                <ul class="importants-links">
                                    <li class="single-link">
                                        <a href="#">policy</a>
                                    </li>
                                    <li class="single-link">
                                        <a href="#">Terms</a>
                                    </li>
                                    <li class="single-link">
                                        <a href="#">FAQ</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class="footer-bottom-content">
                        <p class="copyright-text">copyright © 2026. all right reserved by xKash-Pay</p>
                        <ul class="social-link">
                            <li class="single-social">
                                <a href="#0">
                                    <i class="fa-brands fa-facebook-f"></i>
                                </a>
                            </li>
                            <li class="single-social">
                                <a href="#0">
                                    <i class="fa-brands fa-twitter"></i>
                                </a>
                            </li>
                            <li class="single-social">
                                <a href="#0">
                                    <i class="fa-brands fa-pinterest-p"></i>
                                </a>
                            </li>
                        </ul>
                        <div class="footer-menu">
                            <ul>
                                <li>
                                    <a class='single-menu' href="index.html">home</a>
                                </li>
                                <li>
                                    <a class='single-menu' href="lotteries.html">Lotteries</a>
                                </li>
                                <li>
                                    <a class='single-menu' href="winners.html">Winners</a>
                                </li>
                                <li>
                                    <a class='single-menu' href="contact.html">contact</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- footer end -->

        <!-- back to button begin -->
        <div class="back-to-top-btn">
            <a href="#">
                <i class="fa-solid fa-arrow-turn-up"></i>
            </a>
        </div>
        <!-- back to top button end -->

        <!-- jQuery js -->
        <script src="{{ asset('assets/js/jquery-3.6.0.min.js') }}"></script>
        <!-- bootstrap js -->
        <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
        <!-- owl carousel js -->
        <script src="{{ asset('assets/js/owl.carousel.min.js') }}"></script>
        <!-- main js -->
        <script src="{{ asset('assets/js/main.js') }}"></script>
        <!-- lottery js initialize -->
        <script src="{{ asset('assets/js/lotteries-initialization.js') }}"></script>
        @yield('script')
    </body>
</html>