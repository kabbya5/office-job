@extends('layouts.app')
@section('content')
  <!-- banner begin -->
        <div class="banner">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-6">
                        <div class="banner-content">
                            <h4 class="sub-title">স্বাগতম আমাদের লটারি প্ল্যাটফর্মে!</h4>
                            <h1 class="title">এখানে প্রতিটি ড্র আপনার জীবনে নিয়ে আসতে পারে নতুন সম্ভাবনা ও বড় জয়ের সুযোগ।</h1>
                            <div class="all-btns">
                                <a class='btn-pok' href="lotteries.html">লটারি কিনুন <i class="fa-solid fa-angle-right"></i></a>
                                <a class='btn-pok-2' href="about.html">সাইন আপ <i class="fa-solid fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-8 col-sm-9 d-xl-flex d-lg-flex d-block align-items-end">
                        <div class="part-img">
                            <img class="main-img" src="assets/img/banner-img.png" alt="">
                            <img src="assets/img/power-ball.png" alt="" class="power-ball pok-1">
                            <img src="assets/img/power-ball2.png" alt="" class="power-ball pok-2">
                            <img src="assets/img/power-ball3.png" alt="" class="power-ball pok-3">
                            <img src="assets/img/power-ball4.png" alt="" class="power-ball pok-4">
                            <img src="assets/img/power-ball5.png" alt="" class="power-ball pok-5">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- banner end -->

        <!-- lottery begin -->
        <div class="lotteries">
            <div class="bg-shape-2">
                <img src="assets/img/bg-shape/bg-shape-2.png" alt="">
            </div>
            <div class="bg-shape-1">
                <img src="assets/img/bg-shape/bg-shape-1.png" alt="">
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="section-title">
                            <h3 class="sub-title">সকল লটারি</h3>
                            <h2 class="title">আপনার ভাগ্যবান নম্বরটি বেছে নিন</h2>
                        </div>
                    </div>
                </div>
                <div class="part-picking-number">
                    <div class="lotteries-selection-menu">
                        <ul>
                            <li>
                                <a href="#0" class="single-lottery-item active">
                                    <span class="lottery-icon">
                                        <img src="assets/img/lottery/euro-jackpot.png" alt="">
                                    </span>
                                    <span class="lottery-name">Euro Jackpot</span>
                                </a>
                            </li>
                            <li>
                                <a href="#0" class="single-lottery-item">
                                    <span class="lottery-icon">
                                        <img src="assets/img/lottery/euro-millions.png" alt="">
                                    </span>
                                    <span class="lottery-name">Euro Millions</span>
                                </a>
                            </li>
                            <li>
                                <a href="#0" class="single-lottery-item">
                                    <span class="lottery-icon">
                                        <img src="assets/img/lottery/ena-lotto.png" alt="">
                                    </span>
                                    <span class="lottery-name">Super Enalotto</span>
                                </a>
                            </li>
                            <li>
                                <a href="#0" class="single-lottery-item">
                                    <span class="lottery-icon">
                                        <img src="assets/img/lottery/keno.png" alt="">
                                    </span>
                                    <span class="lottery-name">Keno Lotto</span>
                                </a>
                            </li>
                            <li>
                                <a href="#0" class="single-lottery-item">
                                    <span class="lottery-icon">
                                        <img src="assets/img/lottery/illinois.png" alt="">
                                    </span>
                                    <span class="lottery-name">Illions Lotttery</span>
                                </a>
                            </li>
                            <li>
                                <a href="#0" class="single-lottery-item">
                                    <span class="lottery-icon">
                                        <img src="assets/img/lottery/new-jersey.png" alt="">
                                    </span>
                                    <span class="lottery-name">New Jersey</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="animation-body animated">
                        <div class="picking-number-header">
                            <img src="assets/img/lottery/lottery-header-right-img.png" alt="" class="lottery-bg-img">
                            <div class="part-lottery-info">
                                <div class="part-img selected-lottery-logo">
                                    <img src="assets/img/lottery/euro-jackpot-big.png" alt="">
                                </div>
                                <div class="part-text">
                                    <span class="lottery-name">Euro Jackpot</span>
                                    <span class="estimate-prize">Estimated prize : <span class="prize-amount">$25.0248</span></span>
                                </div>
                            </div>
                            <div class="part-lottery-function-btn">
                                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="pills-numbers-tab" data-bs-toggle="pill" data-bs-target="#pills-numbers" type="button" role="tab" aria-controls="pills-numbers" aria-selected="true">যেকোনো ৬টি সংখ্যা বেছে নিন</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="pills-winners-tab" data-bs-toggle="pill" data-bs-target="#pills-winners" type="button" role="tab" aria-controls="pills-winners" aria-selected="false">বিজয়ীরা</button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="picking-number-body">
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-numbers" role="tabpanel" aria-labelledby="pills-numbers-tab">
                                    <div class="picking-number-palate">
                                        <div class="number-box common">
                                            <button class="single-number">
                                                01
                                            </button>
                                            <button class="single-number">
                                                02
                                            </button>
                                            <button class="single-number">
                                                03
                                            </button>
                                            <button class="single-number selected">
                                                04
                                            </button>
                                            <button class="single-number">
                                                05
                                            </button>
                                            <button class="single-number">
                                                06
                                            </button>
                                            <button class="single-number">
                                                07
                                            </button>
                                            <button class="single-number">
                                                08
                                            </button>
                                            <button class="single-number">
                                                09
                                            </button>
                                            <button class="single-number">
                                                10
                                            </button>
                                            <button class="single-number">
                                                11
                                            </button>
                                            <button class="single-number">
                                                12
                                            </button>
                                            <button class="single-number">
                                                13
                                            </button>
                                            <button class="single-number">
                                                14
                                            </button>
                                            <button class="single-number">
                                                15
                                            </button>
                                            <button class="single-number selected">
                                                16
                                            </button>
                                            <button class="single-number">
                                                17
                                            </button>
                                            <button class="single-number">
                                                18
                                            </button>
                                            <button class="single-number">
                                                19
                                            </button>
                                            <button class="single-number">
                                                20
                                            </button>
                                            <button class="single-number">
                                                21
                                            </button>
                                            <button class="single-number selected">
                                                22
                                            </button>
                                            <button class="single-number">
                                                23
                                            </button>
                                            <button class="single-number">
                                                24
                                            </button>
                                            <button class="single-number">
                                                25
                                            </button>
                                            <button class="single-number">
                                                26
                                            </button>
                                            <button class="single-number">
                                                27
                                            </button>
                                            <button class="single-number">
                                                28
                                            </button>
                                            <button class="single-number">
                                                29
                                            </button>
                                            <button class="single-number selected">
                                                30
                                            </button>
                                            <button class="single-number">
                                                31
                                            </button>
                                            <button class="single-number">
                                                32
                                            </button>
                                            <button class="single-number">
                                                33
                                            </button>
                                            <button class="single-number">
                                                34
                                            </button>
                                            <button class="single-number">
                                                35
                                            </button>
                                            <button class="single-number">
                                                36
                                            </button>
                                            <button class="single-number">
                                                37
                                            </button>
                                            <button class="single-number selected">
                                                38
                                            </button>
                                            <button class="single-number">
                                                39
                                            </button>
                                            <button class="single-number">
                                                40
                                            </button>
                                        </div>
                                        <div class="number-box special">
                                            <button class="single-number">
                                                01
                                            </button>
                                            <button class="single-number">
                                                02
                                            </button>
                                            <button class="single-number">
                                                03
                                            </button>
                                            <button class="single-number">
                                                04
                                            </button>
                                            <button class="single-number">
                                                05
                                            </button>
                                            <button class="single-number selected special">
                                                06
                                            </button>
                                            <button class="single-number">
                                                07
                                            </button>
                                            <button class="single-number">
                                                08
                                            </button>
                                            <button class="single-number">
                                                09
                                            </button>
                                            <button class="single-number">
                                                10
                                            </button>
                                            <button class="single-number">
                                                11
                                            </button>
                                            <button class="single-number">
                                                12
                                            </button>
                                            <button class="single-number">
                                                13
                                            </button>
                                            <button class="single-number">
                                                14
                                            </button>
                                            <button class="single-number">
                                                15
                                            </button>
                                            <button class="single-number">
                                                16
                                            </button>
                                            <button class="single-number">
                                                17
                                            </button>
                                            <button class="single-number">
                                                18
                                            </button>
                                            <button class="single-number">
                                                19
                                            </button>
                                            <button class="single-number">
                                                20
                                            </button>
                                        </div>
                                    </div>
                                    <div class="picking-number-result">
                                        <div class="part-title">
                                            <h3 class="title">নির্বাচিত সংখ্যা:</h3>
                                        </div>
                                        <div class="result-number-palate">
                                            <button class="single-number selected" id="4">
                                                04
                                            </button>
                                            <button class="single-number selected" id="16">
                                                16
                                            </button>
                                            <button class="single-number selected" id="22">
                                                22
                                            </button>
                                            <button class="single-number selected" id="30">
                                                30
                                            </button>
                                            <button class="single-number selected" id="38">
                                                38
                                            </button>
                                            <button class="single-number selected special" id="06">
                                                06
                                            </button>
                                        </div>
                                        <div class="picking-number-quick-buttons">
                                            <button class="clear-btn" id="clear-all-numbers">Clear <i class="fa-solid fa-xmark"></i></button>
                                            <button class="auto-select-btn" id="auto-select-btn">Auto select <i class="fa-solid fa-arrows-rotate"></i></button>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-winners" role="tabpanel" aria-labelledby="pills-winners-tab">
                                    <div class="lottery-winners">
                                        <div class="row">
                                            <div class="col-xl-6 col-lg-6">
                                                <h4 class="lottery-winners-title">সাম্প্রতিক বিজয়ীরা</h4>
                                                <div class="single-winner">
                                                    <div class="part-img">
                                                        <img src="assets/img/lottery/winner-1.jpg" alt="">
                                                    </div>
                                                    <div class="part-text">
                                                        <p><span class="user-name">Richard william</span> ২ মিনিট আগে জিতেছে।</p>
                                                        <ul>
                                                            <li class="plaing-stats">
                                                                <span class="ps-title">Match :</span>
                                                                <span class="ps-descr">02+</span>
                                                            </li>
                                                            <li class="plaing-stats">
                                                                <span class="ps-title">payout :</span>
                                                                <span class="ps-descr">$536.25</span>
                                                            </li>
                                                        </ul>
                                                        <div class="winning-number">
                                                            <span class="single-number selected">01</span>
                                                            <span class="single-number selected">25</span>
                                                            <span class="single-number selected">34</span>
                                                            <span class="single-number selected">43</span>
                                                            <span class="single-number selected">55</span>
                                                            <span class="single-number selected special">02</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="single-winner">
                                                    <div class="part-img">
                                                        <img src="assets/img/lottery/winner-3.jpg" alt="">
                                                    </div>
                                                    <div class="part-text">
                                                        <p><span class="user-name">Rebecca Gaby</span>  has won 13 minutes ago.</p>
                                                        <ul>
                                                            <li class="plaing-stats">
                                                                <span class="ps-title">Match :</span>
                                                                <span class="ps-descr"> 08+</span>
                                                            </li>
                                                            <li class="plaing-stats">
                                                                <span class="ps-title">payout :</span>
                                                                <span class="ps-descr">$325.02</span>
                                                            </li>
                                                        </ul>
                                                        <div class="winning-number">
                                                            <span class="single-number selected">10</span>
                                                            <span class="single-number selected">22</span>
                                                            <span class="single-number selected">30</span>
                                                            <span class="single-number selected">47</span>
                                                            <span class="single-number selected">53</span>
                                                            <span class="single-number selected special">10</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lg-6">
                                                <h4 class="lottery-winners-title">সর্বকালের শীর্ষ বিজয়ী</h4>
                                                <div class="single-winner">
                                                    <div class="part-img">
                                                        <img src="assets/img/lottery/winner-2.jpg" alt="">
                                                    </div>
                                                    <div class="part-text">
                                                        <p><span class="user-name">Summer Colson</span>  has won 3 months ago.</p>
                                                        <ul>
                                                            <li class="plaing-stats">
                                                                <span class="ps-title">Match :</span>
                                                                <span class="ps-descr">08+</span>
                                                            </li>
                                                            <li class="plaing-stats">
                                                                <span class="ps-title">payout :</span>
                                                                <span class="ps-descr">$1,965.00</span>
                                                            </li>
                                                        </ul>
                                                        <div class="winning-number">
                                                            <span class="single-number selected">20</span>
                                                            <span class="single-number selected">35</span>
                                                            <span class="single-number selected">54</span>
                                                            <span class="single-number selected">69</span>
                                                            <span class="single-number selected">35</span>
                                                            <span class="single-number selected special">17</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="single-winner">
                                                    <div class="part-img">
                                                        <img src="assets/img/lottery/winner-4.jpg" alt="">
                                                    </div>
                                                    <div class="part-text">
                                                        <p><span class="user-name">Kai Dellit</span>  has won 7 months ago.</p>
                                                        <ul>
                                                            <li class="plaing-stats">
                                                                <span class="ps-title">Match :</span>
                                                                <span class="ps-descr">08+</span>
                                                            </li>
                                                            <li class="plaing-stats">
                                                                <span class="ps-title">payout :</span>
                                                                <span class="ps-descr">$2,120.25</span>
                                                            </li>
                                                        </ul>
                                                        <div class="winning-number">
                                                            <span class="single-number selected">36</span>
                                                            <span class="single-number selected">21</span>
                                                            <span class="single-number selected">76</span>
                                                            <span class="single-number selected">54</span>
                                                            <span class="single-number selected">77</span>
                                                            <span class="single-number selected special">37</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="part-btn">
                                            <a class='btn-pok' href='/poklotto/lotteries'>সব বিজয়ী দেখুন <i class="fa-solid fa-angle-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- lottery end -->

        <!-- cta begin -->
        <div class="cta">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-9 col-lg-9 col-sm-8 d-xl-flex d-lg-flex d-block align-items-center">
                        <div class="part-text">
                            <h2 class="title">লটারি বা অন্য কোনো বিষয়ে আপনার কোনো জিজ্ঞাসা থাকলে!</h2>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3">
                        <div class="btn-cta">
                            <a class='btn-pok' href="contact.html">যোগাযোগ করুন <i class="fa-solid fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- cta end -->

        <!-- testimonial begin -->
        <div class="testimonial">
            <div class="bg-shape-1">
                <img src="assets/img/bg-shape/bg-shape-1.png" alt="">
            </div>
            <img src="assets/img/bg-shape/bg-shape-3.png" alt="" class="bg-shape-3">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-8 col-lg-8">
                        <div class="section-title">
                            <h3 class="sub-title">প্রশংসাপত্র</h3>
                            <h2 class="title">ক্লায়েন্টের মূল্যবান মতামত</h2>
                        </div>
                    </div>
                </div>
                <div class="testimonial-carousel owl-carousel owl-theme">
                    <div class="single-testimonial">
                        <div class="part-user-info">
                            <span class="user-name">ruhio S albert</span>
                            <span class="lottery-category">MagaMill. Winner</span>
                            <span class="winning-date">( apr - 2022 )</span>
                        </div>
                        <div class="user-img-cover">
                            <div class="part-img">
                                <img src="assets/img/testimonial/user-1.png" alt="">
                            </div>
                        </div>
                        <div class="part-feedback">
                            <p><img class="quot-1" src="assets/img/testimonial/quot-icon-1.png" alt="">
                                যেহেতু সবকিছুই ভাগ্যের উপর নির্ভরশীল, তাই আপনার নম্বর বাছাই করা বা লটারি টার্মিনাল কী ফলাফল দেয় তা দেখা উপভোগ করুন।
                            <img class="quot-2" src="assets/img/testimonial/quot-icon-2.png" alt="">
                        </p>
                        </div>
                    </div>
                    <div class="single-testimonial">
                        <div class="part-user-info">
                            <span class="user-name">Leah Stanley</span>
                            <span class="lottery-category">Powerball. Winner</span>
                            <span class="winning-date">( Jan - 2022 )</span>
                        </div>
                        <div class="user-img-cover">
                            <div class="part-img">
                                <img src="assets/img/testimonial/user-2.png" alt="">
                            </div>
                        </div>
                        <div class="part-feedback">
                            <p><img class="quot-1" src="assets/img/testimonial/quot-icon-1.png" alt="">
                                Since it’s all by chance, enjoy picking your numbers or seeing what the lottery terminal generates Since it’s all by chance.
                            <img class="quot-2" src="assets/img/testimonial/quot-icon-2.png" alt="">
                        </p>
                        </div>
                    </div>
                    <div class="single-testimonial">
                        <div class="part-user-info">
                            <span class="user-name">Megan Clayton</span>
                            <span class="lottery-category">US Lotto. Winner</span>
                            <span class="winning-date">( Dec - 2021 )</span>
                        </div>
                        <div class="user-img-cover">
                            <div class="part-img">
                                <img src="assets/img/testimonial/user-3.png" alt="">
                            </div>
                        </div>
                        <div class="part-feedback">
                            <p><img class="quot-1" src="assets/img/testimonial/quot-icon-1.png" alt="">
                                Since it’s all by chance, enjoy picking your numbers or seeing what the lottery terminal generates Since it’s all by chance.
                            <img class="quot-2" src="assets/img/testimonial/quot-icon-2.png" alt="">
                        </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- testimonial end -->
@endsection